# html tags

Created: November 18, 2023 9:41 AM
Class: Comp456
Reviewed: No

# The `<audio>` tag is used to embed sound content in a document, such as music or other audio streams.

```html
<audio controls>
  <source src="horse.ogg" type="audio/ogg">
  <source src="horse.mp3" type="audio/mpeg">
  Your browser does not support the audio tag.
</audio>
```

# The `<datalist>` tag specifies a list of pre-defined options for an <input> element.

```html
<label for="browser">Choose your browser from the list:</label>
<input list="browsers" name="browser" id="browser">

<datalist id="browsers">
  <option value="Edge">
  <option value="Firefox">
  <option value="Chrome">
  <option value="Opera">
  <option value="Safari">
</datalist>
```

# The `<dd>` tag is used to describe a term/name in a description list.

```html
<dl>
  <dt>Coffee</dt>
  <dd>Black hot drink</dd>
  <dt>Milk</dt>
  <dd>White cold drink</dd>
</dl>
```

# The `<dfn>` tag stands for the "definition element", and it specifies a term that is going to be defined within the content.

```html
<p><dfn>HTML</dfn> is the standard markup language for creating web pages.</p>
```

# The `<div>` tag defines a division or a section in an HTML document.

```html
<div class="myDiv">
  <h2>This is a heading in a div element</h2>
  <p>This is some text in a div element.</p>
</div>
```

# The `<fieldset>` tag is used to group related elements in a form.

```html
/<form action="/action_page.php">
  <fieldset>
    <legend>Personalia:</legend>
    <label for="fname">First name:</label>
    <input type="text" id="fname" name="fname"><br><br>
    <label for="lname">Last name:</label>
    <input type="text" id="lname" name="lname"><br><br>
    <label for="email">Email:</label>
    <input type="email" id="email" name="email"><br><br>
    <label for="birthday">Birthday:</label>
    <input type="date" id="birthday" name="birthday"><br><br>
    <input type="submit" value="Submit">
  </fieldset>
</form>
```

# The `<iframe>` tag specifies an inline frame.

```html
<iframe src="https://www.w3schools.com" title="W3Schools Free Online Web Tutorials"></iframe>
```

# The `<cite>` tag

The `<cite>` tag defines the title of a creative work (e.g. a book, a poem, a song, a movie, a painting, a sculpture, etc.).

**Note:** A person's name is not the title of a work.

The text in the `<cite>` element usually renders in *italic*.

```css
<p><cite>The Scream</cite> by Edward Munch. Painted in 1893.</p>
```

# The `<code>`

The `<code>` tag is used to define a piece of computer code. The content inside is displayed in the browser's default monospace font.

**Tip:** This tag is not deprecated. However, it is possible to achieve richer effect by using CSS (see example below).

```css
<p>The HTML <code>button</code> tag defines a clickable button.</p>

<p>The CSS <code>background-color</code> property defines the background color of an element.</p>
```

# **HTML <dialog> Tag**

The `<dialog>` tag defines a dialog box or subwindow.

The `<dialog>` element makes it easy to create popup dialogs and modals on a web page.

```css
<dialog open>This is an open dialog window</dialog>
```

# **HTML <wbr> Tag**

The `<wbr>` (Word Break Opportunity) tag specifies where in a text it would be ok to add a line-break.

```css
<p>To learn AJAX, you must be familiar with the XML<wbr>Http<wbr>Request Object.</p>
```

# **HTML <script> Tag**

The `<script>` tag is used to embed a client-side script (JavaScript).

The `<script>` element either contains scripting statements, or it points to an external script file through the src attribute.

Common uses for JavaScript are image manipulation, form validation, and dynamic changes of content.

```css
<script>
document.getElementById("demo").innerHTML = "Hello JavaScript!";
</script>
```

# The `<ruby>` tag

The `<ruby>` tag specifies a ruby annotation.

A ruby annotation is a small extra text, attached to the main text to indicate the pronunciation or meaning of the corresponding characters. This kind of annotation is often used in Japanese publications.

Use `<ruby>` together with [<rt>](https://www.w3schools.com/tags/tag_rt.asp) and [<rp>](https://www.w3schools.com/tags/tag_rp.asp): The `<ruby>` element consists of one or more characters that needs an explanation/pronunciation, and an <rt> element that gives that information, and an optional <rp> element that defines what to show for browsers that do not support ruby annotations.

```css
<ruby>
漢 <rt> ㄏㄢˋ </rt>
</ruby>
```

# The `<progress>` tag

The `<progress>` tag represents the completion progress of a task.

**Tip:** Always add the [<label>](https://www.w3schools.com/tags/tag_label.asp) tag for best accessibility practices!

```css
<label for="file">Downloading progress:</label>
<progress id="file" value="32" max="100"> 32% </progress>
```

# The `<kbd>` tag

The `<kbd>` tag is used to define keyboard input. The content inside is displayed in the browser's default monospace font.

**Tip:** This tag is not deprecated. However, it is possible to achieve richer effect by using CSS (see example below).

```css
<p>Press <kbd>Ctrl</kbd> + <kbd>C</kbd> to copy text (Windows).</p>

<p>Press <kbd>Cmd</kbd> + <kbd>C</kbd> to copy text (Mac OS).</p>
```