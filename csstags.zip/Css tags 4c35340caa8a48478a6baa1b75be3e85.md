# Css tags

Created: November 18, 2023 11:42 AM
Class: Comp456
Reviewed: No

# CSS Margins

The CSS `margin` properties are used to create space around elements, outside of any defined borders.

With CSS, you have full control over the margins. There are properties for setting the margin for each side of an element (top, right, bottom, and left).

```css
p {
  margin-top: 100px;
  margin-bottom: 100px;
  margin-right: 150px;
  margin-left: 80px;
}
```

# CSS Padding

The CSS `padding` properties are used to generate space around an element's content, inside of any defined borders.

With CSS, you have full control over the padding. There are properties for setting the padding for each side of an element (top, right, bottom, and left).

```css
div {
  padding-top: 50px;
  padding-right: 30px;
  padding-bottom: 50px;
  padding-left: 80px;
}
```

# Css Color

Changes the color of text,background,border  by the given values like RGB, HEX,….

```css
<!DOCTYPE html>
<html>
<body>

<h1 style="background-color:Tomato;">Tomato</h1>
<h1 style="background-color:Orange;">Orange</h1>
<h1 style="background-color:DodgerBlue;">DodgerBlue</h1>

</body>
</html>

```

# `font-size` - Change the size of text.

```css
h1 {
  font-size: 24px;
}

```

```css
∂mg {
  border: 1px solid black;
}

```

# `width` - Set the width of an element.

```css
.container {
  width: 500px;
}

```

# `height` - Set the height of an element.

```css
.box {
  height: 200px;
}

```

# `display` - Specify the display behavior of an element.

```css
span {
  display: inline-block;
}

```

# `position` - Set the positioning method of an element.

```css
.footer {
  position: fixed;
}

```

# `float` - Specify the floating behavior of an element.

```css
.image {
  float: left;
}

```

# `text-align` - Set the alignment of text within an element.

```css
.header {
  text-align: center;
}

```

# `font-family` - Set the font family for text.

```css
p {
  font-family: "Arial", sans-serif;
}

```

# `text-decoration` - Add decoration to text.

```css
a {
  text-decoration: underline;
}

```

# `list-style` - Set the style of list items.

```css
ul {
  list-style: none;
}

```

# `opacity` - Set the opacity of an element.

```css
.overlay {
  opacity: 0.5;
}

```

# `box-shadow` - Add a shadow effect to an element.

```css
.box {
  box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
}

```

# `text-transform` - Transform text to uppercase, lowercase, or capitalize.

```css
.uppercase {
  text-transform: uppercase;
}

```